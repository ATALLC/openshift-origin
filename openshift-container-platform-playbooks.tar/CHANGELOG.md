This CHANGELOG.md file will contain the update log for the latest set of updates to the templates

# UPDATES for Release 3.7

1.  Created this repository as a central place to store Ansible playbooks that are used.
